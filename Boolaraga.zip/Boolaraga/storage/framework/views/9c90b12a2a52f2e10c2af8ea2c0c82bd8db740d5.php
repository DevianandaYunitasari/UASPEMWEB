
<?php $__env->startSection('title', __('419')); ?>
<?php $__env->startSection('content'); ?>
  <div class="text-center">
    <div class="error mx-auto" data-text="419">419</div>
    <p class="lead text-gray-800 mb-4">Page Expired</p>
    <a href="<?php echo e(url('/')); ?>">&larr; Back to Home</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ticket-Laravel\resources\views/errors/419.blade.php ENDPATH**/ ?>